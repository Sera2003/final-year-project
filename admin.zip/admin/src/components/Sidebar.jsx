import React from 'react'
import { NavLink } from 'react-router-dom'
import { assets } from '../assets/assets'

const Sidebar = () => {
  return (
    <div className='w-[18%] min-h-screen border-r-2'>
      <div className='flex flex-col gap-4 pt-6 pl-[20%] text-[15px]'>

<NavLink className='flex items-center gap-3 border border-gray 300 border-r-0 px-3 py-3 rounded-l' to="/dashboard">
  <img className='w-5 h-5' src={assets.dashboard_icon} alt="" />
  <p className='hidden md:block'>Dashboard</p>
</NavLink>

        <NavLink className='flex items-center gap-3 border border-gray 300 border-r-0 px-3 py-3 rounded-l' to="/add">
          <img className='w-5 h-5' src={assets.add_icon} alt="" />
          <p className='hidden md:block'>Add Items</p>
        </NavLink>

        <NavLink className='flex items-center gap-3 border border-gray 300 border-r-0 px-3 py-3 rounded-l' to="/list">
          <img className='w-5 h-5' src={assets.order_icon} alt="" />
          <p className='hidden md:block'>List Items</p>
        </NavLink>

        <NavLink className='flex items-center gap-3 border border-gray 300 border-r-0 px-3 py-3 rounded-l' to="/orders">
          <img className='w-5 h-5' src={assets.orders_icon} alt="" />
          <p className='hidden md:block'>Orders</p>
        </NavLink>

        <NavLink className='flex items-center gap-3 border border-gray 300 border-r-0 px-3 py-3 rounded-l' to="/users">
          <img className='w-5 h-5' src={assets.users_icon} alt="" />
          <p className='hidden md:block'>Users</p>
        </NavLink>

<NavLink className='flex items-center gap-3 border border-gray 300 border-r-0 px-3 py-3 rounded-l' to="/reviews">
  <img className='w-5 h-5' src={assets.review_icon} alt="" />
  <p className='hidden md:block'>Reviews</p>
</NavLink>


      </div>
    </div>
  )
}

export default Sidebar